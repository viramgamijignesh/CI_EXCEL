<?php
if (!class_exists('PHPExcel')) return false;

$directory = './excel/';
$files = glob($directory . "*");
$results = array();
foreach ($files as $filesName) 
{  

  $inputFileName = $filesName;
  $row_callback=null;
  try {

    $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
    $objReader = PHPExcel_IOFactory::createReader($inputFileType);
    $objReader->setReadDataOnly(true);                              
    $objPHPExcel = $objReader->load($inputFileName);
  } catch(Exception $e) {
    return ('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
  }
  $objWorksheet = $objPHPExcel->getActiveSheet();
  $CurrentWorkSheetIndex = 0;
  foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) 
  {    
    $highestRow = $worksheet->getHighestDataRow();
    $highestColumn = $worksheet->getHighestDataColumn();    
    $headings = $worksheet->rangeToArray('A1:' . $highestColumn . 1,NULL,TRUE,FALSE);    
    $keys = array();    
    if(is_callable($row_callback))
    {
      for ($row = 1; $row <= $highestRow; $row++)
      { 
        $rowData = $worksheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,null,true,false);
        if ($row === 1)
        {
          $keys = $rowData[0];
        } else 
        {
          $record = array();
          foreach($rowData[0] as $pos=>$value)
          $record[$keys[$pos]] = $value; 
          $row_callback($record);           
        }
      } 
    } else 
    {    
      for ($row = 1; $row <= $highestRow; $row++)
      {         
        $rowData = $worksheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, NULL, TRUE, FALSE);
        if ($row === 1){
          $keys = $rowData[0];
        } else 
        {
          $record = array();
          foreach($rowData[0] as $pos=>$value) 
          $record[trim($keys[$pos])] = $value; 
          $results[] = $record;      
        }
      }
    }
  }
} 

?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="row">
        <div class="col-xs-3">
          <h1>
            <i class="fa fa-tachometer" aria-hidden="true"></i> Din oversikt            
          </h1>
         </div>
         <div class="col-xs-9">
          <?php           
          if($role != ROLE_ADMIN)
          {
          ?>
          <div class="panel panel-primary">

                <div class="panel-heading">
                  <div class="pull-right" style="margin-top:-10px;margin-right:-10px"></div>
                  <h6 class="panel-title"><i class="fa fa-comment" style="padding-top:-4px;padding-right:10px;color:#fff"></i>Beskjed!</h6>
                </div>

                <div class="panel-body" style="padding:10px">
                  <?php
                  if(!empty($getBeskjed))
                    {
                        foreach($getBeskjed as $record)
                        {
                          echo $record['message'];
                        }
                    }
                  ?>                  
                </div>
              </div>
         </div>
         <?php
          }
          ?>
      </div>
    </section>
    <?php
        $bordId = '';
        $dato = '';
        $spill = '';
        $resultat = '';
        $status = '';
        $cap = '';
        $dateOfFirst = '';
        $til = '';
        $sum = '';
        $message = '';
        $NICK = '';
        foreach ($results as $value) {
          if (isset($value['NICK'])){
            if (strtolower($name) == strtolower($value['NICK'])){
                $status = isset($value['Status']) ? $value['Status'] : '';
                $NICK = isset($value['NICK'])? $value['NICK'] : '';
                $cap = isset($value['CAP']) ? $value['CAP'] : '';
                $dateOfFirst = isset($value['Dato / Frist']) ? $value['Dato / Frist'] : '';
                $dateOfFirst = PHPExcel_Style_NumberFormat::toFormattedString($dateOfFirst, "DD-MM-YYYY");
                $til = isset($value['TIL']) ? $value['TIL'] : '';
                $sum = isset($value['SUM']) ? $value['SUM'] : '';                
                $message = isset($value['Penger på vei til deg']) ? $value['Penger på vei til deg'] : '';
            }
          }          
        }
    ?>
    <section class="content">        
        <div class="row">
            <div class="col-md-12">
              <div class="panel panel-primary">
                <div class="panel-heading">
                  <div class="pull-right" style="<?php 
                      if (strtolower($name) == strtolower('Tipbox')){
                         echo 'margin-top:3px;';
                      }else{
                        echo 'margin-top:-10px;margin-right:-10px';
                      } ?>">
                    <table cellpadding="0" cellspacing="0">
                      <tbody>
                          
                            
                            

                            <?php 
                            if (strtolower($name) == strtolower('Tipbox')){
                              echo '<tr><td style="font-size: 16px;">Status:&nbsp&nbsp</td>
                            <td class="text-right" style="font-size: 16px;">';
                               echo $status; 
                               echo ' </td>
                                </tr>';
                            }else{
                              echo '<tr><td style="font-size: 16px;">Status:&nbsp&nbsp</td>
                            <td class="text-right" style="font-size: 16px;">';
                              echo $status; 
                              echo ' </td>
                                </tr>';
                            } ?> 
                            
                           
                            <?php 
                            if (strtolower($name) == strtolower('Tipbox')){
                              echo '';
                            }else{
                              echo ' <tr><td style="font-size: 16px;">Cap:</td>
                            <td class="text-right" style="font-size: 16px;">';
                              echo $cap; 
                              echo '</td></tr>';
                            } ?> 
                         
                                                   
                      
                      </tbody>
                    </table>
                  </div>               
                  <h3 class="panel-heading" style="margin: 0;padding: 0;"><i class="fa fa-user" style=""></i>&nbsp<?php echo $name; ?></h3>
                </div>
                <div class="panel-body" style="padding:10px">
                  <a href="" class="btn btn-default btn-flat"><i class=""></i> Oppdater</a>       
                  <a href="<?php echo base_url(); ?>logout" class="btn btn-default btn-flat"><i class="fa fa-sign-out"></i> Logg ut</a>
                </div>
              </div>
            </div>
            <?php 
            
            if (strtolower($name) == strtolower('Tipbox') || $role == ROLE_ADMIN){
               
            }else{
             
            ?>
            <div class="col-md-12">
              <div class="panel panel-primary">
                <div class="panel-heading">
                  <h6 class="panel-title"><i class="fa fa-ticket" style="padding-right:10px;color:#d6d"></i>Penger på vei til deg</h6>
                </div>
                <div class="panel-body" style="padding:0px">
                  <div style="padding:10px">
                    <?php echo $message; ?>                      
                  </div>      
                </div>
              </div>
            </div>

            <div class="col-md-12">
              <div class="panel panel-primary">
                <div class="panel-heading">
                  <h6 class="panel-title"><i class="fa fa-exchange" style="padding-right:10px;color:#ff0"></i> Oppgjør (Skal sendes)</h6>
                </div>
                <div class="panel-body" style="padding:0px">
                  <table id="example2" class="table table-hover" style="width:100%">
                    <thead>
                    <tr>                    
                      <th>Dato</th>
                      <th>Fra</th>
                      <th>Til</th>
                      <th>Sum</th>                      
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><?php echo $dateOfFirst; ?></td>
                        <td><?php echo $NICK; ?></td>
                        <td><?php echo $til; ?></td>
                        <td><?php echo $sum; ?></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <?php } ?>
            <div class="col-md-12">
              <div class="panel panel-primary">
                <div class="panel-heading">
                  <h3 class="panel-heading" style="margin: 0;padding: 0;"><i class="fa fa-list"> Bord Resultater</i>
                  </h3>                    
              </div><!-- /.box-header -->
              <div class="box-body table-responsive no-padding">
                <?php
                if (strtolower($name) == strtolower('Tipbox')){
                  
                ?>
                <table class="table table-hover">
                    <tr>
                      <th>Bord ID</th>
                      <th>Dato</th>
                      <th>Spill</th>
                      <th>TotalTips</th>
                    </tr>
                    <?php
                      $TotalTips = ''; 
                      $sum = 0; 
                      $NICK = '';
                                        
                          foreach ($results as $value) 
                          {
                            $TotalTips = isset($value['TotalTips']) ? $value['TotalTips']: '';
                            $bordId = isset($value['GameCode']) ? $value['GameCode'] : '';
                            $dato = isset($value['DateStarted']) ? $value['DateStarted'] : '';
                            $dato = PHPExcel_Style_NumberFormat::toFormattedString($dato, "DD-MM-YYYY HH:MM");
                            $spill = isset($value['GameType']) ? $value['GameType'] :'';
                      ?>
                    <tr> 
                      <?php if($TotalTips ){?>
                      <td><?php echo $bordId; ?> </td> 
                      <td><?php echo $dato; ?> </td>
                      <td><?php echo $spill; ?> </td>
                      <td><?php echo $TotalTips;?></td>
                      <?php }  ?>  
                    </tr>
                    <?php }  ?>
                  </table>
                <?php }else{?>
                  <table class="table table-hover">
                    <tr>
                      <th>Bord ID</th>
                      <th>Dato</th>
                      <th>Spill</th>
                      <th>Resultat</th>
                    </tr>
                    <?php                      
                        $bordId = '';
                        $dato = '';
                        $spill = '';
                        $resultat = '';
                        $TotalTips = '';                        
                        $data = array();                          
                        foreach ($results as $value) 
                        {
                        	$count = 0;
							if (isset($value['Player']))
							{
	                            if (strtolower($name) != strtolower($value['Player']))
	                            {
	                            	if (isset($value['GameCode'])){
	                            		$bordId = $value['GameCode'];
	                            	}
	                            	if (isset($value['DateStarted'])){
	                            		//$dato = $value['DateStarted'];
	                            		$dato = PHPExcel_Style_NumberFormat::toFormattedString($value['DateStarted'], "DD-MM-YYYY HH:MM");
	                            	}
	                            	if (isset($value['GameType'])){
	                            		$spill = $value['GameType'];
	                            	}
                            	} else {
                            		$count++;
                            		if (isset($value['GameCode'])){
	                            		$bordId = $value['GameCode'];
	                            	}
	                            	if (isset($value['DateStarted'])){
	                            		//$dato = $value['DateStarted'];
	                            		$dato = PHPExcel_Style_NumberFormat::toFormattedString($value['DateStarted'], "DD-MM-YYYY HH:MM");
	                            	}
	                            	if (isset($value['GameType'])){
	                            		$spill = $value['GameType'];
	                            	}
	                            	if (isset($value['Profit'])){
	                            		$resultat = $value['Profit'];
	                            	} else {
	                            		$resultat = "";
	                            	}
                            	}

                            	if ($count == 1){
                            		?>
                            			<tr>
					                      <td><?php echo $bordId; ?> </td> 
					                      <td><?php echo $dato; ?> </td>
					                      <td><?php echo $spill; ?> </td>
					                      <td><?php echo $resultat;?> </td>
					                    </tr>	
                            		<?php
                            	}
                          	}
                        }
                     ?>
                  </table>
                  <?php } ?>                 
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
            
        </div>
    </section>
    <!--<div class="box-footer clearfix">                    
    </div>-->
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "userListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>